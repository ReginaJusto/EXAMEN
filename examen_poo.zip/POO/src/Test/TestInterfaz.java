package Test;

import javax.swing.JOptionPane;

import Interfaces.MetodosOperaciones;
import Tools.Tools;

public class TestInterfaz {
	
	public static void main(String[] args) {
        String Insertar;
		String menu="Insertar,Buscar,Visualizar,Salir";
        menu3(menu);
    }
    public static String boton(String menu) {
        String valores[]=menu.split(",");
        int n;
        n = JOptionPane.showOptionDialog(null," SELECCIONA DANDO CLICK ", " M E N U",
                JOptionPane.NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,null,
                valores,valores[0]);
        return ( valores[n]);
    }

    public static void menu3(String menu)
    {
       MetodosOperaciones Operaciones=new MetodosOperaciones (10);
        String sel="";
        do {
            sel=boton(menu);
            switch(sel){
                case "Insertar":
                    if (Operaciones.insertarDato(JOptionPane.showInputDialog(null,"nombre")))
                        Tools.imprimeMsje("Dato insertado correctamente!");
                     else {
                        Tools.imprimeMsje("�Error! El arreglo est� lleno.");
                    }
                    break;

                case "Buscar":
                    Tools.imprimeMsje("Funcionalidad no implementada ");
                    break;

                case "Visualizar":
                	Operaciones.verDatos();;
                    break;

                case "Salir":
                    Tools.imprimeMsje("selecci�ne otra opci�n.");
                    break;
            }
        } while (!sel.equals("Salir"));
    }

}
