package Tools;

public class Tools {
	
	public static String boton(String menu){
	    // TODO Auto-generated method stub
	    return null;
	}

	public static void imprimeMsje(String string){
	    // TODO Auto-generated method stub
	    System.out.println(string);
	}

	public static void imprimeErrorMsje(){
	    // TODO Auto-generated method stub
	    System.err.println("Ha ocurrido un error.");
	}

	public static void imprimeMsje(String string, int tipo){
	    // TODO Auto-generated method stub
	    if(tipo == 1){
	        System.out.println(string);
	    } else if(tipo == 2){
	        System.err.println(string);
	    }
	}

	public static void imprimeMsje(String string) {
		
		
	}
}

